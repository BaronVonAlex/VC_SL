VEGA Conflict KIXEYE API.

commands for looking up player data via in-game ID and Kixeye user ID.

/stats {id} - VEGA in-game ID.
/kix_id {kixid} - Kixeye USER ID.